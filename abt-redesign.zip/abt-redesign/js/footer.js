document.addEventListener('DOMContentLoaded', function () {
  var mount = document.getElementById('site-footer-include');
  if (!mount) return;
  mount.innerHTML = `
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <div class="logo" style="margin-bottom:14px;">
            <svg class="mark" width="24" height="24" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M13 1L24 7V19L13 25L2 19V7L13 1Z" stroke="currentColor" stroke-width="1.4"/>
              <path d="M14.5 7L9 14H13L11.5 19L18 11H13.5L14.5 7Z" fill="currentColor"/>
            </svg>
            ABT
          </div>
          <p style="max-width:32ch; color:var(--slate);">Manufacturer and repairer of lithium-ion battery packs, engineered and quality-tested in Somerset West, South Africa.</p>
        </div>
        <div>
          <h5>Site</h5>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="services.html">Services &amp; Repair</a></li>
            <li><a href="products.html">Products</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
        <div>
          <h5>Contact</h5>
          <ul>
            <li><a href="tel:+27213305811">T 021 330 5811</a></li>
            <li><a href="mailto:info@batterytech.co.za">info@batterytech.co.za</a></li>
            <li><a href="https://wa.me/+27711908709">WhatsApp us</a></li>
          </ul>
        </div>
        <div>
          <h5>Visit</h5>
          <p>Unit D43 Olive Grove Estate<br>Old Paardevlei Road<br>Somerset West</p>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© Advanced Battery Technologies. All rights reserved.</span>
        <span style="display:flex; gap:18px;">
          <a href="#">Privacy Statement</a>
          <a href="#">Terms &amp; Conditions</a>
        </span>
      </div>
    </div>
  `;
});
